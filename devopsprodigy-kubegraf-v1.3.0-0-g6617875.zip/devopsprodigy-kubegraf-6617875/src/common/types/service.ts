import {BaseModel} from '../../common/types/traits/baseModel';

export class Service extends BaseModel{

    constructor(data){
        super(data);
    }
}
