import {DOPK8SDatasource} from "./datasource";
import {DOPK8SConfig} from "./config";

export {
    DOPK8SDatasource as Datasource,
    DOPK8SConfig as ConfigCtrl
};
